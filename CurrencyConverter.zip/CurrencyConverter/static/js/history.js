// JavaScript для страницы истории сравнений

document.addEventListener('DOMContentLoaded', function() {
    // Инициализация модального окна через Bootstrap
    const comparisonModal = new bootstrap.Modal(document.getElementById('comparisonModal'));
    
    // Находим все кнопки просмотра сравнений
    const viewButtons = document.querySelectorAll('.view-comparison-btn');
    
    // Добавляем обработчики событий на кнопки
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const comparisonId = this.getAttribute('data-comparison-id');
            
            // Показываем модальное окно
            comparisonModal.show();
            
            // Сбрасываем предыдущее содержимое
            document.getElementById('modalContent').style.display = 'none';
            document.getElementById('modalLoading').style.display = 'block';
            document.getElementById('modalResults').innerHTML = '';
            
            // Загружаем данные сравнения
            fetchComparisonDetails(comparisonId);
        });
    });
    
    // Функция для загрузки деталей сравнения
    async function fetchComparisonDetails(comparisonId) {
        try {
            const response = await fetch(`/api/comparison/${comparisonId}`);
            
            if (!response.ok) {
                throw new Error('Ошибка загрузки данных сравнения');
            }
            
            const comparisonData = await response.json();
            
            // Отображаем данные в модальном окне
            displayComparisonDetails(comparisonData);
            
        } catch (error) {
            document.getElementById('modalLoading').innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> Ошибка: ${error.message}
                </div>
            `;
        }
    }
    
    // Функция для отображения деталей сравнения
    function displayComparisonDetails(data) {
        // Показываем контент и скрываем загрузку
        document.getElementById('modalLoading').style.display = 'none';
        document.getElementById('modalContent').style.display = 'block';
        
        // Устанавливаем информацию о сравнении
        document.getElementById('modalFilename').textContent = data.filename;
        
        // Преобразуем дату в удобный формат
        const date = new Date(data.created_at);
        document.getElementById('modalDate').textContent = formatDate(date);
        
        // Отображаем список товаров
        const resultsContainer = document.getElementById('modalResults');
        
        if (data.products && data.products.length > 0) {
            // Отображаем товары
            data.products.forEach(product => {
                const productCard = createProductCard(product);
                resultsContainer.appendChild(productCard);
            });
        } else {
            resultsContainer.innerHTML = `
                <div class="col-12">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i> 
                        В этом сравнении не найдено товаров.
                    </div>
                </div>
            `;
        }
    }
    
    // Функция для создания карточки товара
    function createProductCard(product) {
        const card = document.createElement('div');
        card.className = 'col-12 mb-4';
        
        let kaspiResultsHtml = '';
        
        if (product.kaspi_results && product.kaspi_results.length > 0) {
            kaspiResultsHtml = `
                <div class="table-responsive mt-3">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Название товара</th>
                                <th>Цена</th>
                                <th>Разница</th>
                                <th>Продавцы</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${product.kaspi_results.map(item => `
                                <tr>
                                    <td>${item.kaspi_name}</td>
                                    <td>${formatPrice(item.kaspi_price)} ₸</td>
                                    <td>${formatPriceDifference(item.price_difference_percent)}</td>
                                    <td>${item.sellers ? item.sellers.join(', ') : 'Н/Д'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        } else {
            kaspiResultsHtml = `
                <p class="text-muted fst-italic mt-3">На маркетплейсе Kaspi не найдено результатов</p>
            `;
        }
        
        card.innerHTML = `
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">${product.model}</h5>
                    <span class="badge bg-secondary">Артикул: ${product.sku}</span>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p class="fw-bold mb-1">Наша цена:</p>
                            <h3>${formatPrice(product.our_price)} ₸</h3>
                        </div>
                        <div class="col-md-6">
                            <p class="fw-bold mb-1">Остаток:</p>
                            <h4>${product.stock} шт.</h4>
                        </div>
                    </div>
                    
                    <h5>Результаты с маркетплейса Kaspi</h5>
                    ${kaspiResultsHtml}
                </div>
            </div>
        `;
        
        return card;
    }
    
    // Вспомогательная функция для форматирования цены
    function formatPrice(price) {
        if (!price) return '0';
        
        // Форматировать число с разделителями тысяч
        return parseFloat(price).toLocaleString('ru-RU');
    }
    
    // Вспомогательная функция для форматирования разницы в цене
    function formatPriceDifference(diff) {
        if (diff === null || diff === undefined) return 'Н/Д';
        
        let cssClass = '';
        let prefix = '';
        
        if (diff > 0) {
            cssClass = 'price-up';
            prefix = '+';
        } else if (diff < 0) {
            cssClass = 'price-down';
            prefix = '';
        } else {
            cssClass = 'price-same';
            prefix = '';
        }
        
        return `<span class="${cssClass}">${prefix}${parseFloat(diff).toFixed(2)}%</span>`;
    }
    
    // Функция для форматирования даты
    function formatDate(date) {
        return date.toLocaleString('ru-RU', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
});