// Глобальные переменные
let uploadedFileName = '';
let resultsData = null;

// Обработчик при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Проверка если мы на странице загрузки
    const uploadForm = document.getElementById('uploadForm');
    if (uploadForm) {
        setupUploadPage();
    }

    // Проверка если мы на странице результатов
    const resultsContainer = document.getElementById('resultsContainer');
    if (resultsContainer) {
        setupResultsPage();
    }
});

// Настройка функциональности страницы загрузки
function setupUploadPage() {
    const fileInput = document.getElementById('xmlFile');
    const fileUploadContainer = document.getElementById('fileUploadContainer');
    const uploadForm = document.getElementById('uploadForm');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    const progressBar = document.getElementById('progressBar');
    const progressContainer = document.getElementById('progressContainer');
    const loader = document.getElementById('loader');
    const errorDisplay = document.getElementById('errorDisplay');

    // Обработчик изменения файла
    fileInput.addEventListener('change', function(e) {
        const file = this.files[0];
        if (file) {
            uploadedFileName = file.name;
            fileNameDisplay.textContent = `Выбран: ${uploadedFileName}`;
            fileNameDisplay.style.display = 'block';
        } else {
            fileNameDisplay.style.display = 'none';
        }
    });

    // Обработчики перетаскивания файлов
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        fileUploadContainer.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        fileUploadContainer.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        fileUploadContainer.addEventListener(eventName, unhighlight, false);
    });

    function highlight() {
        fileUploadContainer.classList.add('dragover');
    }

    function unhighlight() {
        fileUploadContainer.classList.remove('dragover');
    }

    fileUploadContainer.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const file = dt.files[0];
        fileInput.files = dt.files;
        
        if (file) {
            uploadedFileName = file.name;
            fileNameDisplay.textContent = `Выбран: ${uploadedFileName}`;
            fileNameDisplay.style.display = 'block';
        }
    }

    // Обработчик отправки формы
    uploadForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const file = fileInput.files[0];
        if (!file) {
            displayError('Пожалуйста, выберите XML-файл для загрузки');
            return;
        }

        if (!file.name.toLowerCase().endsWith('.xml')) {
            displayError('Поддерживаются только XML-файлы');
            return;
        }

        // Очистить предыдущие ошибки
        errorDisplay.style.display = 'none';
        errorDisplay.textContent = '';
        
        // Показать индикаторы прогресса
        progressContainer.style.display = 'block';
        loader.style.display = 'block';
        
        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/scan', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || errorData.detail || 'Ошибка загрузки файла');
            }

            resultsData = await response.json();
            
            // Сохранить результаты в sessionStorage для использования на странице результатов
            sessionStorage.setItem('resultsData', JSON.stringify(resultsData));
            
            // Перенаправить на страницу результатов
            window.location.href = '/results';
            
        } catch (error) {
            displayError(`Ошибка: ${error.message}`);
            progressContainer.style.display = 'none';
            loader.style.display = 'none';
        }
    });

    function displayError(message) {
        errorDisplay.textContent = message;
        errorDisplay.style.display = 'block';
    }
}

// Настройка функциональности страницы результатов
function setupResultsPage() {
    // Попытка получить данные результатов из sessionStorage
    const storedResults = sessionStorage.getItem('resultsData');
    
    if (storedResults) {
        try {
            resultsData = JSON.parse(storedResults);
            displayResults(resultsData);
        } catch (error) {
            displayResultsError('Ошибка обработки сохраненных данных');
        }
    } else {
        displayResultsError('Данные не найдены. Пожалуйста, сначала загрузите XML-файл.');
    }

    // Настройка кнопки "Назад"
    const backBtn = document.getElementById('backToUpload');
    if (backBtn) {
        backBtn.addEventListener('click', function() {
            window.location.href = '/';
        });
    }
}

// Отображение результатов на странице результатов
function displayResults(results) {
    const resultsContainer = document.getElementById('resultsContainer');
    const resultsSummary = document.getElementById('resultsSummary');
    
    if (!results || !results.length) {
        displayResultsError('Товары не найдены в загруженном файле');
        return;
    }

    // Обновить сводку
    resultsSummary.textContent = `Найдено ${results.length} товаров`;
    
    // Очистить контейнер
    resultsContainer.innerHTML = '';
    
    // Добавить информацию о сохранении в историю
    if (results[0] && results[0].comparison_id) {
        const comparisonId = results[0].comparison_id;
        const saveInfo = document.createElement('div');
        saveInfo.className = 'alert alert-success mb-4';
        saveInfo.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="fas fa-save me-3 fa-2x"></i>
                <div>
                    <h4 class="alert-heading mb-1">Результаты сохранены в историю</h4>
                    <p class="mb-0">Это сравнение сохранено и доступно в <a href="/history">истории сравнений</a> под номером ${comparisonId}.</p>
                </div>
            </div>
        `;
        resultsContainer.appendChild(saveInfo);
    }
    
    // Создать карточки результатов
    results.forEach(product => {
        const card = createProductCard(product);
        resultsContainer.appendChild(card);
    });
}

// Создать карточку товара для страницы результатов
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'card result-card mb-4';
    
    const cardHeader = document.createElement('div');
    cardHeader.className = 'card-header d-flex justify-content-between align-items-center';
    
    const modelTitle = document.createElement('h5');
    modelTitle.className = 'mb-0';
    modelTitle.textContent = product.model;
    
    const skuBadge = document.createElement('span');
    skuBadge.className = 'badge bg-secondary';
    skuBadge.textContent = `Артикул: ${product.sku}`;
    
    cardHeader.appendChild(modelTitle);
    cardHeader.appendChild(skuBadge);
    
    const cardBody = document.createElement('div');
    cardBody.className = 'card-body';
    
    const ourPriceRow = document.createElement('div');
    ourPriceRow.className = 'row mb-3';
    ourPriceRow.innerHTML = `
        <div class="col-md-6">
            <p class="fw-bold mb-1">Наша цена:</p>
            <h3>${formatPrice(product.our_price)} ₸</h3>
        </div>
        <div class="col-md-6">
            <p class="fw-bold mb-1">Остаток:</p>
            <h4>${product.stock} шт.</h4>
        </div>
    `;
    
    cardBody.appendChild(ourPriceRow);
    
    // Раздел результатов Kaspi
    const kaspiResultsSection = document.createElement('div');
    kaspiResultsSection.className = 'mt-3';
    
    const kaspiHeader = document.createElement('h5');
    kaspiHeader.textContent = 'Результаты с маркетплейса Kaspi';
    kaspiResultsSection.appendChild(kaspiHeader);
    
    if (product.kaspi_results && product.kaspi_results.length > 0) {
        const kaspiTable = document.createElement('div');
        kaspiTable.className = 'table-responsive';
        kaspiTable.innerHTML = `
            <table class="table table-sm table-hover">
                <thead>
                    <tr>
                        <th>Название товара</th>
                        <th>Цена</th>
                        <th>Разница</th>
                        <th>Продавцы</th>
                    </tr>
                </thead>
                <tbody>
                    ${product.kaspi_results.map(item => `
                        <tr>
                            <td>${item.kaspi_name}</td>
                            <td>${formatPrice(item.kaspi_price)} ₸</td>
                            <td>${formatPriceDifference(item.price_difference_percent)}</td>
                            <td>${item.sellers ? item.sellers.join(', ') : 'Н/Д'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        kaspiResultsSection.appendChild(kaspiTable);
    } else {
        const noResults = document.createElement('p');
        noResults.className = 'text-muted fst-italic';
        noResults.textContent = 'На маркетплейсе Kaspi не найдено результатов';
        kaspiResultsSection.appendChild(noResults);
    }
    
    cardBody.appendChild(kaspiResultsSection);
    
    card.appendChild(cardHeader);
    card.appendChild(cardBody);
    
    return card;
}

// Вспомогательная функция для форматирования цены
function formatPrice(price) {
    if (!price) return '0';
    
    // Удалить нечисловые символы, кроме точки
    const numericValue = price.toString().replace(/[^\d.]/g, '');
    
    // Форматировать число с разделителями тысяч
    return parseFloat(numericValue).toLocaleString('ru-RU');
}

// Вспомогательная функция для форматирования разницы в цене
function formatPriceDifference(diff) {
    if (diff === null || diff === undefined) return 'Н/Д';
    
    let cssClass = '';
    let prefix = '';
    
    if (diff > 0) {
        cssClass = 'price-up';
        prefix = '+';
    } else if (diff < 0) {
        cssClass = 'price-down';
        prefix = '';
    } else {
        cssClass = 'price-same';
        prefix = '';
    }
    
    return `<span class="${cssClass}">${prefix}${diff.toFixed(2)}%</span>`;
}

// Отображение ошибки на странице результатов
function displayResultsError(message) {
    const resultsContainer = document.getElementById('resultsContainer');
    const resultsSummary = document.getElementById('resultsSummary');
    
    resultsSummary.textContent = 'Ошибка';
    
    resultsContainer.innerHTML = `
        <div class="alert alert-danger" role="alert">
            <h4 class="alert-heading">Ошибка</h4>
            <p>${message}</p>
            <hr>
            <p class="mb-0">Пожалуйста, вернитесь назад и попробуйте загрузить другой файл.</p>
        </div>
    `;
}