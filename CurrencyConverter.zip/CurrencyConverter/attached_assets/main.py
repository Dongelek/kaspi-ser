
from fastapi import FastAPI, File, UploadFile
import uvicorn
from parser import process_xml_and_scan

app = FastAPI()

@app.post("/scan")
async def scan_file(file: UploadFile = File(...)):
    content = await file.read()
    return process_xml_and_scan(content)
