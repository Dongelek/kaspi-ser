
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import io
import xml.etree.ElementTree as ET

def normalize_name(name):
    return name.lower().replace(' ', '').replace('-', '').replace('/', '').replace('б/к', '').replace('др', '')

def extract_model_price_from_kaspi(model):
    url = f"https://kaspi.kz/shop/search/?text={model}"
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url)
        page.wait_for_timeout(3000)
        cards = page.locator('.item-card__info')
        data = []
        for i in range(cards.count()):
            try:
                name = cards.nth(i).locator('.item-card__name').inner_text()
                price = cards.nth(i).locator('.item-card__prices-price').inner_text()
                sellers = cards.nth(i).locator('.item-seller__name').all_inner_texts()
                data.append({
                    "kaspi_name": name,
                    "kaspi_price": price,
                    "sellers": sellers
                })
            except Exception:
                continue
        browser.close()
        return data

def process_xml_and_scan(content):
    root = ET.fromstring(content)
    results = []
    for item in root.findall('.//item'):
        sku = item.findtext('sku')
        model = item.findtext('model')
        price = item.findtext('price')
        stock = item.findtext('stock')
        search_results = extract_model_price_from_kaspi(model)
        results.append({
            "sku": sku,
            "model": model,
            "our_price": price,
            "stock": stock,
            "kaspi_results": search_results
        })
    return results
